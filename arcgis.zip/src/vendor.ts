declare var require;

import 'reflect-metadata';
require('zone.js/dist/zone');
require('zone.js/dist/long-stack-trace-zone'); // for development only - not needed for prod deployment

require('./css/bootstrap.css');
require('./css/main.css');

require('./lib/bootstrap/bootstrap.js');

