/*
 * Created with IntelliJ IDEA.
 * User: mfo
 * Date: 12/18/15
 * Time: 10:30 PM
 */
import {Component} from "@angular/core";

@Component({
    selector: 'callback',
    directives: [],
    pipes: [],
    template: `
<div>I'm an OAuth2 Callback</div>
`
})
export class CallbackComponent {
    constructor() {
    }
}
