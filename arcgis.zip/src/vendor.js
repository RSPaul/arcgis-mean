require('angular2/bundles/angular2-polyfills');
require('angular2/platform/browser');
require('angular2/core');
require('angular2/http');
require('angular2/router');
//# sourceMappingURL=vendor.js.map