<h1>ArcGIS Mean</h1>

<p>This is sample code to get user added items using oAuth.</p>

<h2>Installation</h2>

<pre>$ npm install</pre>

<pre>$ npm start</pre>
